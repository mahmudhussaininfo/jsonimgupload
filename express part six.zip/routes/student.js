const express = require('express');
const { getstudents, createstudent, editstudent, singlestudent, studentdata } = require('../controllers/StudentController');


//init router
const router = express.Router();


//routes
router.get('/', getstudents);
router.get('/create', createstudent);
router.post('/create', studentdata);
router.get('/edit', editstudent);
router.get('/:id', singlestudent);

//module
module.exports = router